﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CIS136.Week11AuthService.Models;

namespace CIS136.Week11AuthService.Services
{
    public class UserDatabase
    {
        private List<User> _Users;
        public List<User> Users
        {
            get { return _Users; }
            set { }
        }

        public UserDatabase()
        {
            InitUsers();
        }

        private void InitUsers()
        {
            _Users = new List<User>()
      {
        new User
        {
          UserId = "1"
          ,FirstName = "Jorge"
          ,LastName = "Rivas"



          ,UserName = "jr@elcamino.edu"
          ,Password = "admin1234"



          ,Roles = new List<string>{ "Admin","User", "Professor" }
        },
        new User
        {
           UserId = "2"
          ,FirstName = "Spike"
          ,LastName = "Spiegal"



          ,UserName = "spike@spacecowboy.com"
          ,Password = "user1234"
          ,Roles = new List<string> {"User", "Student" }
        }
      };
        }

        public async Task<User> AddUserAsync(RegistrationRequest reg)
        {
            var usr = new User();
            await Task.Run(() =>
            {
                usr.UserId = (_Users.Count + 1).ToString();
                usr.FirstName = reg.FirstName;
                usr.LastName = reg.LastName;



                usr.UserName = reg.Username;
                usr.Password = reg.Password;



                usr.Roles = new List<String>() { "User" };



                _Users.Add(usr);
            });
            return usr;
        }



        public async Task<List<User>> GetUsersAsync()
        {
            await Task.FromResult(true);
            return _Users;
        }



        public async Task<User> GetUserAsync(String id)
        {
            var usr = new User();
            await Task.Run(() =>
            {
                foreach (var itm in _Users)
                {
                    if (itm.UserId.ToString() == id)
                    {
                        usr = itm;
                    }
                }
            });
            return usr;
        }



        public async Task<User> SaveUserAsync(User person)
        {
            await Task.Run(() =>
            {
                foreach (var itm in _Users)
                {
                    if (itm.UserId == person.UserId)
                    {
                        itm.UserName = person.UserName;
                        itm.FirstName = person.FirstName;
                        itm.LastName = person.LastName;
                        person = itm;
                    }
                }
            });
            return person;
        }



        public async Task<int> DeleteUserAsync(String UserId)
        {
            int NumDeleted = 0;
            await Task.Run(() =>
            {
                User usr = null;
                foreach (var itm in _Users)
                {
                    if (itm.UserId == UserId)
                    {
                        usr = itm; break;
                    }
                }
                if (usr != null)
                {
                    if (_Users.Remove(usr))
                    {
                        NumDeleted = 1;
                    }
                }
            });
            return NumDeleted;
        }



        public async Task<int> AddRoleAsync(UserRole role)
        {
            int NumRoles = 0;
            await Task.Run(() =>
            {
                User usr = null;
                foreach (var itm in _Users)
                {
                    if (itm.UserId == role.UserId)
                    {
                        usr = itm; break;
                    }
                }
                if (usr != null)
                {
                    usr.Roles.Add(role.RoleName);
                    NumRoles = usr.Roles.Count;
                }
            });
            return NumRoles;
        }



        public async Task<int> DeleteRoleAsync(UserRole role)
        {
            int NumRoles = 0;
            await Task.Run(() =>
            {
                User usr = null;
                foreach (var itm in _Users)
                {
                    if (itm.UserId == role.UserId)
                    {
                        usr = itm; break;
                    }
                }
                if (usr != null)
                {
                    usr.Roles.Remove(role.RoleName);
                    NumRoles = usr.Roles.Count;
                }
            });
            return NumRoles;
        }
    }

}

