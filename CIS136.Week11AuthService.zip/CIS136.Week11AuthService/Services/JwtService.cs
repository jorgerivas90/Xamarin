﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using CIS136.Week11AuthService.Models;

namespace CIS136.Week11AuthService.Services
{
    public class JwtService
    {
        public JwtService()
        {



        }

        public string GenerateJwtToken(User user)
        {
            var clms = new List<Claim>()
      {
        new Claim(JwtRegisteredClaimNames.Sub, user.UserName),
        new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName),
        new Claim(JwtRegisteredClaimNames.FamilyName, user.LastName),
        new Claim(JwtRegisteredClaimNames.GivenName, user.FirstName),
        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
      };



            clms.Add(new Claim("UserId", user.UserId.ToString()));
            foreach (var role in user.Roles)
            {
                clms.Add(new Claim(ClaimTypes.Role, role));
            }



            //Need at least 128bits of random data
            var KeyBytes = System.Text.Encoding.ASCII.GetBytes("SVuipN1LR1zq1KSX7C99Cmr9Pc8vKK8OuSuXd6FtNiKDkmmbn7qt4MIoe5g57rbVmYY5HQdOdTaN9wALCtrMbysEeulq7yXXC8bAdGhP8646BTrbHtBeiGsr6csLsc25");



            var token = new JwtSecurityToken
            (
              issuer: "http://192.168.0.112:5001",
              audience: "http://192.168.0.112:5000",
              claims: clms,
              notBefore: DateTime.UtcNow,
              expires: DateTime.UtcNow.AddDays(365),
              signingCredentials: new SigningCredentials(new SymmetricSecurityKey(KeyBytes), SecurityAlgorithms.HmacSha256Signature)
            );



            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
