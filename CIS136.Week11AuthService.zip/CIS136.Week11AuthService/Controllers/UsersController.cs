﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using CIS136.Week11AuthService.Services;
using CIS136.Week11AuthService.Models;

namespace CIS136.Week11AuthService.Controllers
{
    [ApiController, Route("[controller]"), Authorize]
    public class UsersController : ControllerBase
    {
        private UserDatabase _UserDatabase;
        private JwtService _jwtService;



        public UsersController(UserDatabase UserDB, JwtService jwtService)
        {
            _UserDatabase = UserDB;
            _jwtService = jwtService;
        }



        [HttpPost("register"), AllowAnonymous]
        public async Task<IActionResult> Register(RegistrationRequest reg)
        {
            var rsp = new RegistrationResponse();



            var usr = await _UserDatabase.AddUserAsync(reg);



            rsp.UserId = usr.UserId;
            rsp.Message = "User has been Registered";
            rsp.UserName = usr.UserName;
            rsp.LastName = usr.LastName;
            rsp.FirstName = usr.FirstName;



            return Ok(rsp);
        }



        [HttpPost("authenticate"), AllowAnonymous]
        public async Task<ActionResult<CredentialResponse>> Authenticate(CredentialRequest cred)
        {
            User user = null;
            var usrs = await _UserDatabase.GetUsersAsync();
            foreach (var usr in usrs)
            {
                if ((usr.UserName.ToUpper() == cred.Username.ToUpper()) && usr.Password == cred.Password)
                {
                    user = usr; break;
                }
            }



            var rsp = new CredentialResponse() { Username = cred.Username };
            if (user == null)
            {
                rsp.Message = "Username or password is incorrect";
                return BadRequest(rsp);
            }



            rsp.Token = _jwtService.GenerateJwtToken(user);
            rsp.Message = "Successfully Logon";
            return Ok(rsp);
        }



        [HttpPost("AddRole"), Authorize(Roles = "Admin")]
        public async Task<IActionResult> AddRole(UserRole role)
        {
            await _UserDatabase.AddRoleAsync(role);
            return Ok();
        }



        [HttpPost("DelRole"), Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteRole(UserRole role)
        {
            await _UserDatabase.DeleteRoleAsync(role);
            return Ok();
        }



        [HttpGet, Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetUsers()
        {
            var usrs = await _UserDatabase.GetUsersAsync();
            return Ok(usrs);
        }



        [HttpGet("{id}"), Authorize(Roles = "User,Admin")]
        public async Task<IActionResult> GetUser(string Id)
        {
            User usr;



            var UserId = User.FindFirst("UserId")?.Value;
            if (User.IsInRole("Admin") || (UserId == Id))
            {
                usr = await _UserDatabase.GetUserAsync(Id);
            }
            else
            {
                return Unauthorized("You do not have access to this account");
            }



            return Ok(usr);
        }



        [HttpPost, Authorize(Roles = "User,Admin")]
        public async Task<IActionResult> Post([FromBody] User person)
        {
            var UserId = User.FindFirst("UserId")?.Value;
            if (User.IsInRole("Admin") || (UserId == person.UserId))
            {
                person = await _UserDatabase.SaveUserAsync(person);
            }
            else
            {
                return Unauthorized("You do not have access to this account");
            }
            return Ok(person);
        }



        [HttpDelete("{id}"), Authorize(Roles = "User,Admin")]
        public async Task<IActionResult> Delete(String Id)
        {
            var UserId = User.FindFirst("UserId")?.Value;
            if (User.IsInRole("Admin") || (UserId == Id))
            {
                await _UserDatabase.DeleteUserAsync(Id);
            }
            else
            {
                return Unauthorized("You do not have access to this account");
            }
            return Ok();
        }
    }
}
