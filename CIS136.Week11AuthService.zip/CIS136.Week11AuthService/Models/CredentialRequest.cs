﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CIS136.Week11AuthService.Models
{
    public class CredentialRequest
    {

        [Required]
        public string Username { get; set; }



        [Required]
        public string Password { get; set; }
    }
}
