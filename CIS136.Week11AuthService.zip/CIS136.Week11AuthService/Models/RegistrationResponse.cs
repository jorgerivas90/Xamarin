﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CIS136.Week11AuthService.Models
{
    public class RegistrationResponse
    {
        public string UserId { get; set; }



        public string UserName { get; set; }



        public string LastName { get; set; }



        public string FirstName { get; set; }



        public string Message { get; set; }
    }
}
