﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CIS136.Week04.SQLite.Model;
using CIS136.Week04.SQLite.Database;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CIS136.Week05.WebAPI.Controllers
{
    [ApiController, Route("[controller]")]
    public class ContactsController : ControllerBase
    {
        private static string _FilePath = "";

        public ContactsController(IWebHostEnvironment host)
        {
            _FilePath = host.ContentRootPath;
        }

        private static ContactDatabase _database;
        public static ContactDatabase Database
        {
            get
            {
                if (_database == null)
                {
                    _database = new ContactDatabase(_FilePath);
                    if (_database.GetContactCount() == 0)
                    {
                        _database.SaveContactAsync(new Contact("Hac", "Le"));
                    }
                }
                return _database;
            }
        }

        [HttpGet]// GET http://localhost/Contacts/
        public async Task<List<Contact>> Get()
        {
            var OrginalThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
            var lst = await Database.GetContactsAsync().ConfigureAwait(false);
            var NewThreadId = System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();

            foreach (var person in lst)
            {
                person.StateCode = OrginalThreadId;
                person.ZipCode = NewThreadId;
            }
            return lst;
        }

        [HttpGet("{id}")]// GET http://localhost/Contacts/5
        public async Task<Contact> Get(int id)
        {
            return await Database.GetContactAsync(id);
        }


        [HttpPost]// POST http://localhost/Contacts/
        public async Task Post([FromBody] Contact person)
        {
            await Database.SaveContactAsync(person);
        }


        [HttpPut("{id}")]// PUT http://localhost/Contacts/5
        public async Task Put(int id, [FromBody] Contact person)
        {
            await Database.SaveContactAsync(person);
        }

        [HttpDelete("{id}")]// DELETE http://localhost/Contacts/5
        public async Task Delete(int id)
        {
            var prn = new Contact() { ContactId = id };
            await Database.DeleteContactAsync(prn);
        }
    }
}
