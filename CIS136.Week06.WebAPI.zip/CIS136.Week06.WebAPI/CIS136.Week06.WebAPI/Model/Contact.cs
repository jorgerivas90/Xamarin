﻿using System;
using SQLite;

namespace CIS136.Week04.SQLite.Model
{
    [Table("Contacts")]
    public class Contact
    {
        #region Private Fields
        private int _ContactId;
        private string _FirstName = "";
        private string _LastName = "";
        private string _Address = "";
        private string _City = "";
        private string _StateCode = "";
        private string _ZipCode = "";
        #endregion

        #region Public Properties

        [Column("ContactId"), PrimaryKey, AutoIncrement]
        public int ContactId
        {
            get { return _ContactId; }
            set
            {
                if (value > 0)
                {
                    _ContactId = value;
                }
            }
        }

        [Column("FirstName"), MaxLength(50), NotNull]
        public string FirstName
        {
            get { return _FirstName ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 50)
                {
                    _FirstName = value;
                }
                else
                {
                    _FirstName = value;
                }

            }
        }

        [Column("LastName"), MaxLength(50)]
        public string LastName
        {
            get { return _LastName ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 50)
                {
                    _LastName = value;
                }
                else
                {
                    _LastName = value;
                }
            }
        }

        [Ignore]
        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }

        [Column("Address01"), MaxLength(50)]
        public string Address
        {
            get { return _Address ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 50)
                {
                    _Address = value;
                }
                else
                {
                    _Address = value;
                }
            }
        }

        [Column("City"), MaxLength(50)]
        public string City
        {
            get { return _City ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 50)
                {
                    _City = value;
                }
                else
                {
                    _City = value;
                }
            }
        }

        [Column("StateCode"), MaxLength(4)]
        public string StateCode
        {
            get { return _StateCode ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 4)
                {
                    _StateCode = value;
                }
                else
                {
                    _StateCode = value;
                }
            }
        }

        [Column("ZipCode"), MaxLength(10)]
        public string ZipCode
        {
            get { return _ZipCode ?? ""; }
            set
            {
                value = value ?? "";
                if (value.Length <= 10)
                {
                    _ZipCode = value;
                }
                else
                {
                    _ZipCode = value;
                }
            }
        }

        #endregion

        public Contact() { }

        public Contact(string fname = "", string lname = "")
        {
            LastName = lname;
            FirstName = fname;
        }
    }
}
