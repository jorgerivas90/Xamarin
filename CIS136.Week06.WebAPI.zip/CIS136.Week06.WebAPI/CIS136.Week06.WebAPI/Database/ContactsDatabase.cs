﻿using System;
using System.IO;
using SQLite;
using System.Collections.Generic;
using System.Threading.Tasks;
using CIS136.Week04.SQLite.Model;


namespace CIS136.Week04.SQLite.Database
{
    public class ContactDatabase
    {
        public readonly SQLiteAsyncConnection _database;
        public ContactDatabase()
        {
            var dbPath = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            if (!Directory.Exists(dbPath))
            {
                Directory.CreateDirectory(dbPath);
            }
            var dbFileName = "Contacts.db3";
            var dbFullPath = Path.Combine(dbPath, dbFileName);
            _database = new SQLiteAsyncConnection(dbFullPath);
            _database.CreateTableAsync<Contact>().Wait();
        }

        public ContactDatabase(string FilePath)
        {
            var FileName = "Contacts.db3";
            var FullPath = Path.Combine(FilePath, FileName);
            _database = new SQLiteAsyncConnection(FullPath);
            _database.CreateTableAsync<Contact>().Wait();
        }
        public int GetContactCount()
        {
            return _database.Table<Contact>().CountAsync().Result;
        }

        public Task<List<Contact>> GetContactsAsync()
        {
            return _database.Table<Contact>().ToListAsync();
        }

        public Task<Contact> GetContactAsync(int id)
        {
            return _database.Table<Contact>()
                            .Where(i => i.ContactId == id)
                            .FirstOrDefaultAsync();
        }

        public Task<int> SaveContactAsync(Contact person)
        {
            if (person.ContactId != 0)
            {
                return _database.UpdateAsync(person);
            }
            else
            {
                return _database.InsertAsync(person);
            }
        }

        public Task<int> DeleteContactAsync(Contact person)
        {
            return _database.DeleteAsync(person);
        }
    }
}
