﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using CIS136.Week04.SQLite.Model;
using CIS136.Week04.SQLite.Database;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CIS136.Week05.WebAPI.Controllers
{
    [ApiController, Route("[controller]")]
    public class ContactsController : ControllerBase
    {
        private ContactDatabase _contactDB;
        public ContactsController(ContactDatabase contactDB)
        {
            _contactDB = contactDB;
        }



        [HttpGet("test"), AllowAnonymous]
        public async Task<IActionResult> Test()
        {
            await Task.Delay(500);
            return Ok(5);
        }



        [HttpGet, Authorize(Roles = "User")]
        public async Task<IActionResult> Get()
        {
            List<Contact> lst = new List<Contact>();
            var cnts = await _contactDB.GetContactsAsync();
            if (cnts != null)
            {
                lst = cnts;
            }
            return Ok(lst);
        }



        [HttpPost, Authorize(Roles = "User,Admin")]
        public async Task<IActionResult> Post([FromBody] Contact person)
        {
            await _contactDB.SaveContactAsync(person);
            return Ok(person);
        }



        [HttpPut, Authorize(Roles = "User")]
        public async Task<IActionResult> Put([FromBody] Contact person)
        {
            await _contactDB.SaveContactAsync(person);
            return Ok(person);
        }



        [HttpDelete("{id}"), Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var person = new Contact() { ContactId = id };
            var NumDeleted = await _contactDB.DeleteContactAsync(person);
            return Ok(NumDeleted);
        }
    }
}
