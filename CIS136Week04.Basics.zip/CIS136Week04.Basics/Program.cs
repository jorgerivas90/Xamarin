﻿using System;

namespace CIS136Week04.Basics
{
    class Program
    {
        public class Person
        {
            public static int NumberofPeopleCreated = 0;

            //Fields
            private string firstName;
            private string lastName;
            private string city;
            private int age;
            private int zipCode;

            //Properties

            public string FirstName
            {
                get { return firstName ?? ""; }
                set { firstName = (value ?? ""); }
            }
            public string LastName
            {
                get { return lastName ?? ""; }
                set { lastName = (value ?? ""); }
            }
            public int Age
            {
                get { return age; }
                set { if (value > 0) { age = value; } }
            }
            public string City
            {
                get { return city ?? ""; }
                set { city = (value ?? ""); }
            }
            public int ZipCode
            {
                get { return zipCode; }
                set { if (value > 0) { zipCode = value; } }
            }

            
            // Default Constructor
            public Person()
            {
                Person.NumberofPeopleCreated++;
            }
         
            //Additional Constructor
            public Person(string fname, string lname, int age)
            {
                firstName = fname;
                lastName = lname;
                Age = age;
                Person.NumberofPeopleCreated++;
            }

            public Person(string fname, string lname, int age, string City, int zipCode)
            {
                firstName = fname;
                lastName = lname;
                Age = age;
                city = City;
               ZipCode = zipCode;
                Person.NumberofPeopleCreated++;
            }

            //Methods
            public string Eat(string food)
            {
                return food;
            }
            public int Sleep(int sleep)
            {
                return sleep;
            }
        }

        static void Main(string[] args)
        {
            Person person = new Person();
            person.FirstName = "Lazlo";
            person.LastName = "Rivas";
            person.Age = 31;
            Console.WriteLine("My name is " + person.FirstName + " " + person.LastName + ". I am " + person.Age + " years old.");

            Person person1 = new Person("Jackie", "Daytona", 36);

            Console.WriteLine("My name is " + person1.FirstName + " " + person1.LastName + ". I am " + person1.Age + " years old.");

            Console.WriteLine(person.FirstName + " ate " + person.Eat("Chinese Food"));
            Person person2 = new Person("Jorge", "Rivas", 31, "Inglewood", 90303);

            Console.WriteLine(Person.NumberofPeopleCreated + " people created.");

            Console.WriteLine("My name is " + person2.FirstName + " " + person2.LastName + ". I am " + person2.Age + " years old. I live in the city of " + person2.City + ", " + person2.ZipCode + ", I just ate " + person2.Eat("Chinese Food") + " and slept for " + person2.Sleep(8) + " hours.");
            


        }
    }
}
